module.exports = {
  projectId: "197571",
  projectKey: "784b1ec61da5cc33985edc0f0babd61d"
};
// https://shing.airbrake.io/projects/197571/edit
