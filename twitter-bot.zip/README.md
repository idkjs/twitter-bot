# [Create a Serverless Twitter Bot with Airbrake and AWS Lambda – Part 1](https://airbrake.io/blog/nodejs/serverless-twitter-bot-airbrake-lambda-part-1)

---

# [Create a Serverless Twitter Bot with Airbrake and AWS Lambda – Part 2](https://airbrake.io/blog/nodejs/serverless-twitter-bot-airbrake-lambda-part-2)
