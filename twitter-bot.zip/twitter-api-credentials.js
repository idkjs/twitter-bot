module.exports = {
  consumer_key: "q3cMlvbhXaqI454CQ5zMTY9OA",
  consumer_secret: "KQelEWDDCiarrdO8m8OPNKGBd8jZ06uiFuoZBxcbegUn2jEtMl",
  access_token_key: "22362043-XWi9kDmkReDdd3AmW3uIVKPI0HxmnbFUFvRIV4Tu0",
  access_token_secret: "2nSsqxdDqUljIVoPislVRIezBRjhgLrrdDV1TEf8s9pgb"
};
